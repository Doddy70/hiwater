import React from "react";

const SingleMoreActionDropdown = () => {
  return <div>SingleMoreActionDropdown</div>;
};

export default SingleMoreActionDropdown;
